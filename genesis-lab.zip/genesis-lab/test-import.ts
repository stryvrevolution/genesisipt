import type { Question } from '@/types/mini-scan-33q';
import { DIMENSION_WEIGHTS } from '@/types/mini-scan-33q';
console.log('Import OK');
