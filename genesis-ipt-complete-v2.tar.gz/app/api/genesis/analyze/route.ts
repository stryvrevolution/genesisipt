import { z } from 'zod';
import mapping from '@/lib/genesis/mapping/questions_to_axes.json';
import { computeIPTScore } from '@/lib/genesis/scoring/scoring-engine';
import { detectPatterns } from '@/lib/genesis/patterns/pattern-detector';
import { generateOutput } from '@/lib/genesis/output/output-generator';
import { runQualityChecks } from '@/lib/genesis/quality/quality-contract';
import { logQualityEvents } from '@/lib/genesis/quality/quality-logger';

const BodySchema = z.object({
  mode: z.enum(['ipt','gplus','omni']).default('ipt'),
  answers: z.record(z.any()),
});

export async function POST(req: Request) {
  const json = await req.json();
  const parsed = BodySchema.safeParse(json);
  if (!parsed.success) {
    return Response.json({ ok: false, error: parsed.error.flatten() }, { status: 400 });
  }

  const { mode, answers } = parsed.data;

  const scoring = computeIPTScore(answers, mapping as any);
  const patterns = detectPatterns({ ipt_global: scoring.ipt_global, axes: scoring.axes });

  const output = generateOutput({
    mode,
    scoring_version: scoring.scoring_version,
    ipt_global: scoring.ipt_global,
    axes: scoring.axes,
    patterns,
  });

  // quality checks (required ids = all question_ids in mapping)
  const requiredIds = (mapping as any).questions.map((q: any) => q.question_id);
  const qualityEvents = runQualityChecks({
    answers,
    required_question_ids: requiredIds,
    ipt_global: scoring.ipt_global,
    axes: scoring.axes,
  });

  logQualityEvents(qualityEvents);

  return Response.json({
    ok: true,
    scoring,
    patterns,
    output,
    quality: qualityEvents,
  });
}
